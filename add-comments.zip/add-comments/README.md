# add-comments README

This extension adds comments in PHP with a context menu.
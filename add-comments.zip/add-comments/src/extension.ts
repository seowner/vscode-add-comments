import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
    let disposable = vscode.commands.registerCommand('extension.addComment', function () {
        vscode.window.showInputBox({ prompt: 'Enter your comment' }).then(value => {
            if (value) {
                const editor = vscode.window.activeTextEditor;
                if (editor) {
                    const languageId = editor.document.languageId;
                    const comment = formatCommentForLanguage(value, languageId);
                    const position = editor.selection.active;
                    editor.edit(editBuilder => {
                        editBuilder.insert(position, comment);
                    });
                }
            }
        });
    });

    context.subscriptions.push(disposable);
}

function formatCommentForLanguage(commentText: string, languageId: string) {

    switch (languageId) {
        case 'php':
        case 'javascript':
            return `// ${commentText}\n// --------------------------------------------\n`;
        case 'python':
            return `# ${commentText}\n# --------------------------------------------\n`;
        case 'html':
            return `<!--------------------------------------------\n ${commentText}\n -------------------------------------------->`;
        case 'css':
            return `/* --------------------------------------------\n ${commentText}\n -------------------------------------------- */`;
        // Add more cases for other languages as needed
        default:
            return `// ${commentText}\n`;
    }
}

export function deactivate() {}
